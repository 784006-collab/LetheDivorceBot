# from modifierScripts.GlobalRegistry import *
# from everythingexcepthim import process_effects, applystatus
# from UnitProfileCode import ProfileData
#
# @register_modifier
# class TemplateHandler(ModifierHandler):
#     name = "INSERTNAMEHERE"
#
#     async def apply(self, value, modifier_target : ProfileData, acquired_values, effect, log, roll_container, pagename, symbol, **kwargs):
#         raise NotImplementedError